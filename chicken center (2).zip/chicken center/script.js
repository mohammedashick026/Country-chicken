// Data Storage
let menuItems = [];
let cart = [];
let sales = [];

// Initialize default menu items
function initializeMenu() {
    const defaultMenu = [
        {
            id: 1,
            name: "Fresh Chicken",
            weight: "250g",
            price: 150.00,
            image: "https://images.unsplash.com/photo-1604503468506-a8da13d82791?w=400&h=300&fit=crop"
        },
        {
            id: 2,
            name: "Fresh Chicken",
            weight: "500g",
            price: 280.00,
            image: "https://images.unsplash.com/photo-1604503468506-a8da13d82791?w=400&h=300&fit=crop"
        },
        {
            id: 3,
            name: "Fresh Chicken",
            weight: "750g",
            price: 400.00,
            image: "https://images.unsplash.com/photo-1604503468506-a8da13d82791?w=400&h=300&fit=crop"
        },
        {
            id: 4,
            name: "Fresh Chicken",
            weight: "1kg",
            price: 520.00,
            image: "https://images.unsplash.com/photo-1604503468506-a8da13d82791?w=400&h=300&fit=crop"
        }
    ];

    // Load from localStorage or use defaults
    const savedMenu = localStorage.getItem('chickenCenterMenu');
    if (savedMenu) {
        menuItems = JSON.parse(savedMenu);
    } else {
        menuItems = defaultMenu;
        saveMenu();
    }

    // Load cart
    const savedCart = localStorage.getItem('chickenCenterCart');
    if (savedCart) {
        cart = JSON.parse(savedCart);
        updateCartCount();
    }

    // Load sales
    const savedSales = localStorage.getItem('chickenCenterSales');
    if (savedSales) {
        sales = JSON.parse(savedSales);
    }
}

// Save menu to localStorage
function saveMenu() {
    localStorage.setItem('chickenCenterMenu', JSON.stringify(menuItems));
}

// Save cart to localStorage
function saveCart() {
    localStorage.setItem('chickenCenterCart', JSON.stringify(cart));
}

// Save sales to localStorage
function saveSales() {
    localStorage.setItem('chickenCenterSales', JSON.stringify(sales));
}

// Show section
function showSection(sectionName, event) {
    // Hide all sections
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });

    // Remove active class from all nav buttons
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('active');
    });

    // Show selected section
    document.getElementById(sectionName + '-section').classList.add('active');
    
    // Add active class to clicked nav button
    if (event) {
        event.target.classList.add('active');
    } else {
        // Find and activate the corresponding nav button
        document.querySelectorAll('.nav-btn').forEach(btn => {
            if (btn.textContent.toLowerCase().includes(sectionName.toLowerCase()) || 
                (sectionName === 'menu' && btn.textContent.includes('Menu'))) {
                btn.classList.add('active');
            }
        });
    }

    // Load content based on section
    if (sectionName === 'menu') {
        loadMenu();
    } else if (sectionName === 'cart') {
        loadCart();
    } else if (sectionName === 'admin') {
        loadAdminMenu();
    } else if (sectionName === 'reports') {
        loadReports();
    }
}

// Load menu items
function loadMenu() {
    const menuGrid = document.getElementById('menu-grid');
    menuGrid.innerHTML = '';

    menuItems.forEach(item => {
        const menuItem = document.createElement('div');
        menuItem.className = 'menu-item';
        menuItem.onclick = () => addToCart(item.id);
        menuItem.innerHTML = `
            <img src="${item.image}" alt="${item.name}" class="menu-item-image" onerror="this.src='https://via.placeholder.com/300x200?text=Chicken'">
            <div class="menu-item-info">
                <div class="menu-item-name">${item.name}</div>
                <div class="menu-item-weight">${item.weight}</div>
                <div class="menu-item-price">₹${item.price.toFixed(2)}</div>
            </div>
        `;
        menuGrid.appendChild(menuItem);
    });
}

// Add item to cart
function addToCart(itemId) {
    const item = menuItems.find(i => i.id === itemId);
    if (!item) return;

    const existingItem = cart.find(c => c.id === itemId);
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({
            id: item.id,
            name: item.name,
            weight: item.weight,
            price: item.price,
            quantity: 1
        });
    }

    saveCart();
    updateCartCount();
    
    // Show notification
    showNotification(`${item.name} (${item.weight}) added to cart!`);
}

// Update cart count
function updateCartCount() {
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    document.getElementById('cart-count').textContent = totalItems;
}

// Load cart
function loadCart() {
    const cartItems = document.getElementById('cart-items');
    
    if (cart.length === 0) {
        cartItems.innerHTML = '<p class="empty-cart">Your cart is empty</p>';
        document.getElementById('cart-total').textContent = '0.00';
        return;
    }

    cartItems.innerHTML = '';
    let total = 0;

    cart.forEach((item, index) => {
        const itemTotal = item.price * item.quantity;
        total += itemTotal;

        const cartItem = document.createElement('div');
        cartItem.className = 'cart-item';
        cartItem.innerHTML = `
            <div class="cart-item-info">
                <div class="cart-item-name">${item.name}</div>
                <div class="cart-item-details">${item.weight}</div>
            </div>
            <div class="cart-item-quantity">
                <button class="quantity-btn" onclick="updateQuantity(${index}, -1)">-</button>
                <span>${item.quantity}</span>
                <button class="quantity-btn" onclick="updateQuantity(${index}, 1)">+</button>
            </div>
            <div class="cart-item-price">₹${itemTotal.toFixed(2)}</div>
        `;
        cartItems.appendChild(cartItem);
    });

    document.getElementById('cart-total').textContent = total.toFixed(2);
}

// Update quantity
function updateQuantity(index, change) {
    cart[index].quantity += change;
    
    if (cart[index].quantity <= 0) {
        cart.splice(index, 1);
    }
    
    saveCart();
    updateCartCount();
    loadCart();
}

// Clear cart
function clearCart() {
    if (cart.length === 0) return;
    
    if (confirm('Are you sure you want to clear the cart?')) {
        cart = [];
        saveCart();
        updateCartCount();
        loadCart();
        showNotification('Cart cleared!');
    }
}

// Proceed to payment
function proceedToPayment() {
    if (cart.length === 0) {
        alert('Your cart is empty!');
        return;
    }

    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    document.getElementById('payment-total').textContent = total.toFixed(2);
    
    document.getElementById('payment-modal').style.display = 'flex';
}

// Close payment modal
function closePaymentModal() {
    document.getElementById('payment-modal').style.display = 'none';
}

// Generate bill
function generateBill() {
    if (cart.length === 0) {
        alert('Cart is empty!');
        return;
    }

    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const billDate = new Date().toLocaleString('en-IN');
    const billNumber = 'BILL-' + Date.now();

    // Prepare bill data
    const billData = [
        ['CHICKEN CENTER - BILL'],
        ['Bill No:', billNumber],
        ['Date:', billDate],
        [''],
        ['Item', 'Weight', 'Quantity', 'Price', 'Total'],
    ];

    cart.forEach(item => {
        billData.push([
            item.name,
            item.weight,
            item.quantity,
            `₹${item.price.toFixed(2)}`,
            `₹${(item.price * item.quantity).toFixed(2)}`
        ]);
    });

    billData.push(['']);
    billData.push(['Total Amount:', '', '', '', `₹${total.toFixed(2)}`]);
    billData.push(['']);
    billData.push(['Thank you for your purchase!']);

    // Create workbook
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.aoa_to_sheet(billData);

    // Set column widths
    ws['!cols'] = [
        { wch: 20 },
        { wch: 15 },
        { wch: 12 },
        { wch: 15 },
        { wch: 15 }
    ];

    XLSX.utils.book_append_sheet(wb, ws, 'Bill');
    XLSX.writeFile(wb, `Bill_${billNumber}.xlsx`);

    // Save sale record
    const sale = {
        billNumber: billNumber,
        date: new Date(),
        items: JSON.parse(JSON.stringify(cart)),
        total: total
    };
    sales.push(sale);
    saveSales();

    // Clear cart after bill generation
    cart = [];
    saveCart();
    updateCartCount();
    closePaymentModal();
    showSection('menu');
    loadMenu();
    
    showNotification('Bill generated successfully!');
}

// Admin functions
function loadAdminMenu() {
    const adminList = document.getElementById('admin-menu-list');
    adminList.innerHTML = '';

    menuItems.forEach(item => {
        const adminItem = document.createElement('div');
        adminItem.className = 'admin-menu-item';
        adminItem.innerHTML = `
            <div class="admin-menu-item-info">
                <strong>${item.name}</strong> - ${item.weight} - ₹${item.price.toFixed(2)}
            </div>
            <div class="admin-menu-item-actions">
                <button class="btn btn-primary" onclick="editMenuItem(${item.id})">Edit</button>
                <button class="btn btn-danger" onclick="deleteMenuItem(${item.id})">Delete</button>
            </div>
        `;
        adminList.appendChild(adminItem);
    });
}

function showAddItemForm() {
    document.getElementById('add-item-form').style.display = 'flex';
    document.getElementById('item-form').reset();
    document.getElementById('item-id').value = '';
}

function closeAddItemForm() {
    document.getElementById('add-item-form').style.display = 'none';
}

function saveMenuItem(event) {
    event.preventDefault();
    
    const id = document.getElementById('item-id').value;
    const name = document.getElementById('item-name').value;
    const weight = document.getElementById('item-weight').value;
    const price = parseFloat(document.getElementById('item-price').value);
    const image = document.getElementById('item-image').value;

    if (id) {
        // Edit existing item
        const index = menuItems.findIndex(item => item.id == id);
        if (index !== -1) {
            menuItems[index] = { id: parseInt(id), name, weight, price, image };
        }
    } else {
        // Add new item
        const newId = menuItems.length > 0 ? Math.max(...menuItems.map(i => i.id)) + 1 : 1;
        menuItems.push({ id: newId, name, weight, price, image });
    }

    saveMenu();
    closeAddItemForm();
    loadAdminMenu();
    showNotification('Menu item saved successfully!');
}

function editMenuItem(id) {
    const item = menuItems.find(i => i.id === id);
    if (!item) return;

    document.getElementById('item-id').value = item.id;
    document.getElementById('item-name').value = item.name;
    document.getElementById('item-weight').value = item.weight;
    document.getElementById('item-price').value = item.price;
    document.getElementById('item-image').value = item.image;
    
    document.getElementById('add-item-form').style.display = 'flex';
}

function deleteMenuItem(id) {
    if (!confirm('Are you sure you want to delete this item?')) return;

    menuItems = menuItems.filter(item => item.id !== id);
    saveMenu();
    loadAdminMenu();
    showNotification('Menu item deleted!');
}

// Reports
function loadReports() {
    const reportContent = document.getElementById('report-content');
    const selectedMonth = document.getElementById('report-month').value;
    
    if (!selectedMonth) {
        reportContent.innerHTML = '<p>Select a month to view sales report</p>';
        return;
    }

    generateReport();
}

function generateReport() {
    const selectedMonth = document.getElementById('report-month').value;
    if (!selectedMonth) return;

    const [year, month] = selectedMonth.split('-');
    const monthSales = sales.filter(sale => {
        const saleDate = new Date(sale.date);
        return saleDate.getFullYear() == year && saleDate.getMonth() + 1 == month;
    });

    const reportContent = document.getElementById('report-content');
    
    if (monthSales.length === 0) {
        reportContent.innerHTML = '<p>No sales found for this month</p>';
        return;
    }

    let totalRevenue = 0;
    let totalItems = 0;

    let html = `
        <table class="report-table">
            <thead>
                <tr>
                    <th>Bill No</th>
                    <th>Date</th>
                    <th>Items</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
    `;

    monthSales.forEach(sale => {
        totalRevenue += sale.total;
        const itemCount = sale.items.reduce((sum, item) => sum + item.quantity, 0);
        totalItems += itemCount;
        
        const saleDate = new Date(sale.date).toLocaleString('en-IN');
        const itemsList = sale.items.map(item => 
            `${item.name} (${item.weight}) x${item.quantity}`
        ).join(', ');

        html += `
            <tr>
                <td>${sale.billNumber}</td>
                <td>${saleDate}</td>
                <td>${itemsList}</td>
                <td>₹${sale.total.toFixed(2)}</td>
            </tr>
        `;
    });

    html += `
            </tbody>
        </table>
        <div class="report-summary">
            <h3>Summary</h3>
            <p><strong>Total Bills:</strong> ${monthSales.length}</p>
            <p><strong>Total Items Sold:</strong> ${totalItems}</p>
            <p><strong>Total Revenue:</strong> ₹${totalRevenue.toFixed(2)}</p>
        </div>
    `;

    reportContent.innerHTML = html;
}

function exportReport() {
    const selectedMonth = document.getElementById('report-month').value;
    if (!selectedMonth) {
        alert('Please select a month first!');
        return;
    }

    const [year, month] = selectedMonth.split('-');
    const monthSales = sales.filter(sale => {
        const saleDate = new Date(sale.date);
        return saleDate.getFullYear() == year && saleDate.getMonth() + 1 == month;
    });

    if (monthSales.length === 0) {
        alert('No sales found for this month!');
        return;
    }

    const reportData = [
        ['MONTHLY SALES REPORT'],
        ['Month:', selectedMonth],
        [''],
        ['Bill No', 'Date', 'Items', 'Total']
    ];

    let totalRevenue = 0;
    monthSales.forEach(sale => {
        totalRevenue += sale.total;
        const saleDate = new Date(sale.date).toLocaleString('en-IN');
        const itemsList = sale.items.map(item => 
            `${item.name} (${item.weight}) x${item.quantity}`
        ).join('; ');

        reportData.push([
            sale.billNumber,
            saleDate,
            itemsList,
            sale.total.toFixed(2)
        ]);
    });

    reportData.push(['']);
    reportData.push(['Total Revenue:', '', '', totalRevenue.toFixed(2)]);

    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.aoa_to_sheet(reportData);

    ws['!cols'] = [
        { wch: 20 },
        { wch: 25 },
        { wch: 40 },
        { wch: 15 }
    ];

    XLSX.utils.book_append_sheet(wb, ws, 'Sales Report');
    XLSX.writeFile(wb, `Sales_Report_${selectedMonth}.xlsx`);
    
    showNotification('Report exported successfully!');
}

// Clear all reports/sales data
function clearReports() {
    if (sales.length === 0) {
        alert('No sales data to clear!');
        return;
    }

    if (confirm('Are you sure you want to clear ALL sales reports? This action cannot be undone!')) {
        sales = [];
        saveSales();
        
        // Clear the report display
        document.getElementById('report-content').innerHTML = '<p>Select a month to view sales report</p>';
        document.getElementById('report-month').value = '';
        
        showNotification('All sales reports cleared!');
    }
}

// Notification
function showNotification(message) {
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #667eea;
        color: white;
        padding: 15px 25px;
        border-radius: 5px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        z-index: 2000;
        animation: slideIn 0.3s ease;
    `;
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Add CSS animation
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    initializeMenu();
    loadMenu();
    updateCartCount();
    
    // Set current month as default
    const now = new Date();
    const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
    document.getElementById('report-month').value = currentMonth;
});

